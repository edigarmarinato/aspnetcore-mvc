---
title: Check square
categories:
  - Alerts, warnings, and signs
tags:
  - checkmark
  - confirm
  - done
---
