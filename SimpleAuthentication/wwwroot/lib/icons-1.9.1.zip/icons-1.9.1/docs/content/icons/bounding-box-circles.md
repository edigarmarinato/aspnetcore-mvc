---
title: Bounding box circles
categories:
  - Graphics
tags:
  - text
  - shape
  - resize
  - dimensions
---
