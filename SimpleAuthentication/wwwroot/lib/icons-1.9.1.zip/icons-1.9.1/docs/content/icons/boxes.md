---
title: Boxes
categories:
tags:
  - cube
---
