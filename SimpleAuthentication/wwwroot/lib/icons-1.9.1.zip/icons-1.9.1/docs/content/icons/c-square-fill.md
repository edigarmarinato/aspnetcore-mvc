---
title: C square fill
categories:
  - Shapes
tags:
  - copyright
---
