---
title: Badge Sd
categories:
  - Badges
tags:
  - display
  - resolution
  - "standard definition"
---
